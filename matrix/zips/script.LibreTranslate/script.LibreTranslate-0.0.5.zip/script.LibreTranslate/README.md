# script.LibreTranslate
Kodi addon to integrate with LibreTranslate to be able to translate on the fly
