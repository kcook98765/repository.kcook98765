
class ShortlistItem:
    title = ""
    plot = ""
    plotoutline = ""
    duration = 0
    date = ""
    year = 0
    rating = 0.0
    thumb = ""   
    poster = ""
    fanart = ""
    filename = ""
    banner = ""
    clearart = ""
    clearlogo = ""
    landscape = ""
    icon = "" 
    