DevView

As you interact with kodi, use this tool to view data/information related to the current highlighted item.

When highlighted on a Movie, TV episode or music track, use teh context menu "DevView".

This will bring up a fullscreen view of a text version of the report

Best view of data is via a web browser on same machine, or if port is set and available to your network, you can access via web browser:

http://172.0.0.1:9999

(127.0.0.1 is if browser is on same machine, else use the ip of the kodi machine)
(port 9999 is default, but you can set another port in settings)

This http:// view is a copy of the last "DevView" run via context menu, and is much nicer to view.
