DevView

As you interact with kodi, use this tool to view data/information related to the current highlighted item.

When highlighted on a Movie, TV episode or music track, use the context menu "DevView".

This will bring up a fullscreen view of a text version of the report

Best view of data is via a web browser on same machine, access via web browser:

http://172.0.0.1:9999

This html view is a copy of the last "DevView" run , and is much nicer to view.
